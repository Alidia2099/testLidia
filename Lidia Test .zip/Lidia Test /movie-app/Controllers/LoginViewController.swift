//
//  LoginViewController.swift
//  movie-app
//
//  Created by Lidia on 05/03/23.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
