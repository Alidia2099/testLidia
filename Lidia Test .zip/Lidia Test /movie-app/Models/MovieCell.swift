//
//  MovieCell.swift
//  movie-app
//
//  Created by Lidia on 05/03/23.
//

import UIKit

class MovieCell: UICollectionViewCell {
    static let reuseIdentifier = String(describing: MovieCell.self)
    
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var movieLabel: UILabel!
}
